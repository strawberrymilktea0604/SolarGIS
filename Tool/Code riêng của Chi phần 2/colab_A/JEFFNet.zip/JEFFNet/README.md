# JEFFNet: Joint-Embedding Predictive Architecture for Solar PV Panel Fault Classification

This repository contains the official implementation of **JEFFNet (JEPA-EFFicientNet)**, a multibranch architecture for thermal infrared (IR) photovoltaic (PV) panel fault classification. JEFFNet fuses self-supervised semantic representations from a JEPA-pretrained Vision Transformer with supervised convolutional features from EfficientNetV2-S to achieve accurate and parameter-efficient fault classification.

## Overview
<img width="944" height="573" alt="jeffnet (2)" src="https://github.com/user-attachments/assets/e0b8f20c-903f-43a2-beca-da43e9b3797a" />

The rapid expansion of solar PV systems has made manual inspection impractical at scale. Thermal IR imaging offers a non-contact way to detect PV faults, but classification remains difficult due to class imbalance, limited texture information, and subtle thermal differences between fault types.

JEFFNet addresses these challenges by combining two complementary feature-extraction pathways:

- **JEPA branch**: A Vision Transformer pretrained using the StoP-JEPA self-supervised framework on ImageNet-1k, providing semantically rich latent representations.
- **EfficientNetV2-S branch**: A supervised convolutional backbone providing discriminative, task-specific features.

The two branches are projected into a shared representation space, refined through branch-specific transformation modules, concatenated, and passed to a classifier head for final fault prediction. The model is trained using a staged fine-tuning strategy: the JEPA encoder is first kept frozen while the EfficientNetV2-S branch and classifier head are trained, after which the full network is fine-tuned end-to-end.

## Key Results

JEFFNet was evaluated on two public thermal IR datasets, **PVF-10** and **InfraredSolarModules (ISM)**, in both multiclass and derived binary (healthy vs. faulty) settings.

| Dataset | Task | F1-score | Accuracy |
|---|---|---|---|
| PVF-10 | 10-class | 93.21 | 94.33 |
| PVF-10 | 2-class (healthy/faulty) | 97.53 | 96.41 |
| ISM | 12-class | 72.60 | 83.88 |
| ISM | 2-class (healthy/faulty) | 94.69 | 94.78 |

Compared with GEPFNet, the previous state-of-the-art model, JEFFNet achieves competitive or superior performance while using only **108.6M parameters versus 205.91M**, a **47.2% reduction** in model size.

## Architecture

JEFFNet processes an input thermal IR image through two parallel branches:

1. The image is patchified and passed through a JEPA context encoder (ViT-B/16), producing patch-level semantic features that are aggregated via global average pooling.
2. The same image is passed through an EfficientNetV2-S backbone, producing spatial convolutional features that are also aggregated via global average pooling.

Each branch representation is passed through a **projector** (fully connected layer, layer normalization, GELU) and a **scaler** (two fully connected layers with intermediate normalization and activation). The two transformed representations are concatenated and passed to a **classifier head** (fully connected layer, layer normalization, GELU, dropout, final fully connected layer) to produce the final class logits.

## Datasets

- **PVF-10**: 5,579 annotated thermal IR images (112x112) collected via UAV from operational PV farms, annotated into 10 fault classes plus a healthy class.
- **InfraredSolarModules (ISM)**: 20,000 IR images (24x40) covering 11 anomaly types plus a no-anomaly class.

Dataset splits, class distributions, and preprocessing details are described in the paper.

## Implementation Details

- Input images are resized to 224x224.
- The JEPA branch uses a ViT-B/16 encoder initialized from the ImageNet-1k pretrained StoP-JEPA checkpoint.
- Data augmentation: random horizontal flip (p=0.5), random vertical flip (p=0.5), brightness jittering (factor 0.5).
- Training: 100 epochs total, staged fine-tuning (10 epochs frozen JEPA encoder, 90 epochs full fine-tuning).
- Learning rate: 3e-4 for newly initialized layers, 1e-5 for the pretrained JEPA encoder after unfreezing.
- Batch size: 128, trained on an NVIDIA A100-40GB GPU.
- Loss: weighted cross-entropy with balanced class weighting to handle class imbalance.

## Repository Structure

```
.
├── data/                 # Dataset loading and preprocessing scripts
├── models/               # JEFFNet, JEPA, and EfficientNetV2-S model definitions
├── train.py              # Training script with staged fine-tuning
├── evaluate.py           # Evaluation script (accuracy, F1, precision, recall, AUC, MCC)
├── configs/               # Configuration files for experiments
└── README.md
```

## Installation

```bash
git clone https://github.com/Azimi2kht/JEFFNet.git
cd JEFFNet
pip install -r requirements.txt
```

## Usage

Training:

```bash
python train.py --config configs/pvf10.yaml
```

Evaluation:

```bash
python evaluate.py --config configs/pvf10.yaml --checkpoint path/to/checkpoint.pt
```

## Evaluation Metrics

Since both datasets are imbalanced, results are reported using macro-averaged metrics: accuracy, precision, recall, F1-score, macro-averaged one-vs-rest AUC, and multiclass Matthews correlation coefficient (MCC).

## Citation

If you use this code or find this work helpful, please cite:

```
@article{azimidokht2026jeffnet,
  title={Joint-Embedding Predictive Architecture for Solar PV Panel Fault Classification},
  author={Azimidokht, Seyyedhamid and Monemi, Mehdi and Kharbouch, Abdelhak and Hamzehaghdam, Farid and Rasti, Mehdi and Aghaei, Jamshid and Kurvinen, Emil},
  year={2026}
}
```

## Acknowledgments

This work builds on the StoP-JEPA and EfficientNetV2 architectures, and is evaluated on the PVF-10 and InfraredSolarModules (ISM) public datasets.

## License
MIT

#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""TN-A2 — chạy checkpoint JEFFNet (train trên PVF-10) lên ảnh cắt của dự án, chấm nhị phân cấp tấm.

Dùng ĐÚNG cách gộp nhị phân của tác giả (runs/*/aggregate_binary.py): dự đoán = lớp healthy → lành,
còn lại → lỗi. Không train lại gì. Ba cách gộp từ ảnh cắt lên tấm, in cả ba:
  best  — chỉ khung tốt nhất của tấm (cột tot_nhat=1 trong manifest), giống PVF-10 một ảnh/tấm
  any   — tấm lỗi nếu BẤT KỲ khung nào dự đoán lỗi (tương đương k=1 của pipeline dự án)
  major — tấm lỗi nếu ≥ nửa số khung dự đoán lỗi (quy tắc Bommes 2022)

Đầu ra: <out>/a2_<bien_the>.json (P/R/F1 + bootstrap 95 % theo tấm, ma trận nhầm lẫn 10 lớp trên
ảnh cắt để biết model gán lỗi của mình vào lớp nào của họ) và <out>/logits_<bien_the>.npz.

    python danh_gia_tam_cat.py --ckpt runs/A1/best.pt --pretrained stop/vit-b16.pth.tar \
        --tam-cat data/tam_cat --manifest data/tam_cat/tam_cat_manifest.csv --out runs/A1
"""
import argparse
import csv
import json
import os
import sys
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
import timm
import torch
import torch.nn as nn
from PIL import Image
from torchvision import transforms

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import StoP.src.deit as deit  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--ckpt", required=True, help="best.pt của lượt train A1")
ap.add_argument("--pretrained", required=True, help="stop/vit-b16.pth.tar (chỉ để dựng kiến trúc)")
ap.add_argument("--tam-cat", required=True, help="thư mục có ori/ và mask/")
ap.add_argument("--manifest", required=True)
ap.add_argument("--out", required=True)
ap.add_argument("--res", type=int, default=224)
ap.add_argument("--model-name", default="deit_base")
ap.add_argument("--patch-size", type=int, default=16)
ap.add_argument("--batch-size", type=int, default=64)
ap.add_argument("--bien-the", nargs="+", default=["ori", "mask"])
ap.add_argument("--B", type=int, default=2000, help="số lượt bootstrap")
args = ap.parse_args()
dev = "cuda" if torch.cuda.is_available() else "cpu"


# ---- kiến trúc chép nguyên từ train.py (train.py chạy argparse + train ở mức module, không import được)
class FusionVitEff(nn.Module):
    def __init__(self, vit_encoder, num_classes, effnet_name="tf_efficientnetv2_s", vit_dim=768,
                 proj_dim=512, hidden_dim=512, dropout=0.2):
        super().__init__()
        self.vit = vit_encoder
        self.vit_projector = nn.Sequential(nn.Linear(vit_dim, proj_dim), nn.LayerNorm(proj_dim), nn.GELU(), nn.Dropout(dropout))
        self.vit_scaler = nn.Sequential(nn.Linear(proj_dim, proj_dim), nn.LayerNorm(proj_dim), nn.GELU(), nn.Dropout(dropout), nn.Linear(proj_dim, proj_dim))
        self.effnet = timm.create_model(effnet_name, pretrained=False, num_classes=0, global_pool="avg")
        eff_dim = self.effnet.num_features
        self.eff_projector = nn.Sequential(nn.Linear(eff_dim, proj_dim), nn.LayerNorm(proj_dim), nn.GELU(), nn.Dropout(dropout))
        self.eff_scaler = nn.Sequential(nn.Linear(proj_dim, proj_dim), nn.LayerNorm(proj_dim), nn.GELU(), nn.Dropout(dropout), nn.Linear(proj_dim, proj_dim))
        self.classifier = nn.Sequential(nn.Linear(2 * proj_dim, hidden_dim), nn.LayerNorm(hidden_dim), nn.GELU(), nn.Dropout(dropout), nn.Linear(hidden_dim, num_classes))

    def forward(self, x):
        z = self.vit(x)
        z = z.mean(dim=1) if z.ndim == 3 else z
        f_vit = self.vit_scaler(self.vit_projector(z))
        f_eff = self.eff_scaler(self.eff_projector(self.effnet(x)))
        return self.classifier(torch.cat([f_eff, f_vit], dim=1))


ck = torch.load(args.ckpt, map_location="cpu", weights_only=False)
class_names = ck["class_names"]
print("Lớp của checkpoint:", class_names)
healthy = [i for i, c in enumerate(class_names) if "healthy" in c.lower()]
assert len(healthy) == 1, "không tìm được đúng một lớp healthy trong %s" % class_names
HEALTHY = healthy[0]

enc = deit.__dict__[args.model_name](img_size=[args.res], patch_size=args.patch_size, predictor_embed_dim=384)
model = FusionVitEff(enc, num_classes=len(class_names))
msg = model.load_state_dict(ck["model_state_dict"], strict=True)
model.to(dev).eval()
print("Nạp checkpoint epoch %s, val_acc %.4f — %s" % (ck.get("epoch"), ck.get("best_val_acc", float("nan")), msg))

tf = transforms.Compose([transforms.Resize((args.res, args.res)), transforms.ToTensor(),
                         transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])])

rows = list(csv.DictReader(open(args.manifest, encoding="utf-8")))
print("Manifest: %d ảnh cắt, %d tấm" % (len(rows), len({r["ma_tam"] for r in rows})))
os.makedirs(args.out, exist_ok=True)
RNG = np.random.default_rng(1008)


def prf(y, yhat):
    tp = int(((y == 1) & (yhat == 1)).sum()); fp = int(((y == 0) & (yhat == 1)).sum()); fn = int(((y == 1) & (yhat == 0)).sum())
    P = tp / (tp + fp) if tp + fp else float("nan"); R = tp / (tp + fn) if tp + fn else float("nan")
    F = 2 * P * R / (P + R) if (P + R) and not np.isnan(P + R) else float("nan")
    return dict(TP=tp, FP=fp, FN=fn, TN=int(len(y) - tp - fp - fn), P=round(P, 4), R=round(R, 4), F1=round(F, 4))


def ktc(y, yhat):
    acc = defaultdict(list)
    for _ in range(args.B):
        i = RNG.integers(0, len(y), len(y)); m = prf(y[i], yhat[i])
        for k in ("P", "R", "F1"): acc[k].append(m[k])
    return {k: [round(float(np.nanpercentile(v, 2.5)), 4), round(float(np.nanpercentile(v, 97.5)), 4)] for k, v in acc.items()}


for bt in args.bien_the:
    col = "file_" + bt
    files = [Path(args.tam_cat) / Path(r[col]).relative_to("du_lieu/tam_cat") if r[col].startswith("du_lieu/tam_cat") else Path(args.tam_cat) / r[col] for r in rows]
    thieu = [f for f in files if not f.exists()]
    if thieu:
        # thử đường dẫn tương đối kiểu <tam_cat>/<bt>/<lop>/<file>
        files = [Path(args.tam_cat) / bt / Path(r[col]).parent.name / Path(r[col]).name for r in rows]
        thieu = [f for f in files if not f.exists()]
    assert not thieu, "thiếu %d file, ví dụ %s" % (len(thieu), thieu[0])

    logits = []
    with torch.no_grad():
        for i in range(0, len(files), args.batch_size):
            x = torch.stack([tf(Image.open(f).convert("RGB")) for f in files[i:i + args.batch_size]]).to(dev)
            logits.append(model(x).float().cpu().numpy())
    logits = np.concatenate(logits)
    pred = logits.argmax(1)
    pred_loi = (pred != HEALTHY).astype(int)                    # gộp nhị phân đúng cách của tác giả
    y_anh = np.array([int(r["nhi_phan"]) for r in rows])
    np.savez_compressed(Path(args.out) / f"logits_{bt}.npz", logits=logits, pred=pred, y=y_anh,
                        ma_tam=np.array([r["ma_tam"] for r in rows]), seq=np.array([r["seq"] for r in rows]))

    # ma trận: nhãn của mình (4 lớp + tot) → lớp của họ (10)
    cheo = defaultdict(Counter)
    for r, p in zip(rows, pred): cheo[r["tinh_trang"]][class_names[p]] += 1

    # gộp lên tấm
    tam = defaultdict(list); best = {}
    for r, p in zip(rows, pred_loi):
        tam[r["ma_tam"]].append(int(p))
        if r.get("tot_nhat") == "1": best[r["ma_tam"]] = int(p)
    ma = sorted(tam); y = np.array([int(next(r["nhi_phan"] for r in rows if r["ma_tam"] == m)) for m in ma])
    gop = {
        "any":   np.array([max(tam[m]) for m in ma]),
        "major": np.array([int(sum(tam[m]) * 2 >= len(tam[m])) for m in ma]),
        "best":  np.array([best.get(m, max(tam[m])) for m in ma]),
    }
    kq = dict(bien_the=bt, ckpt=args.ckpt, healthy_index=HEALTHY, class_names=class_names,
              so_anh=len(rows), so_tam=len(ma), tam_loi=int(y.sum()), tam_lanh=int((1 - y).sum()),
              cap_anh_cat=prf(y_anh, pred_loi),
              cap_tam={k: dict(**prf(y, v), ktc95=ktc(y, v)) for k, v in gop.items()},
              nhan_minh_sang_lop_ho={k: dict(v) for k, v in cheo.items()})
    json.dump(kq, open(Path(args.out) / f"a2_{bt}.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("\n=== %s ===" % bt)
    print("  cấp ảnh cắt: P %.3f R %.3f F1 %.3f" % (kq["cap_anh_cat"]["P"], kq["cap_anh_cat"]["R"], kq["cap_anh_cat"]["F1"]))
    for k, v in kq["cap_tam"].items():
        print("  cấp tấm %-5s: P %.3f R %.3f F1 %.3f  KTC F1 %s" % (k, v["P"], v["R"], v["F1"], v["ktc95"]["F1"]))
print("\nĐã ghi vào", args.out)

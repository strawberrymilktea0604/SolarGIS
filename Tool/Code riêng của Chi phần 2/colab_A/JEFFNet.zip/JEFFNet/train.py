import argparse
import json
import logging
from pathlib import Path

import numpy as np
import timm
import torch
import torch.nn as nn
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader, Subset
from torchvision import datasets, transforms

import StoP.src.deit as deit
import wandb
from src.helper import save_training_plots
from utils.evaluation import ClassificationEvaluator
from utils.reproduce import set_seed

logging.basicConfig()
logger = logging.getLogger()
logger.setLevel(logging.INFO)


parser = argparse.ArgumentParser()

parser.add_argument("--patch-size", type=int, default=16, help="patch-size (pixels)")
parser.add_argument("--res", type=int, default=224, help="resolution")
parser.add_argument("--lambd", type=float, default=0.00025, help="regularization")
parser.add_argument(
    "--penalty",
    type=str,
    help="regularization for logistic classifier",
    default="l2",
    choices=["l2", "elastic-net"],
)
parser.add_argument(
    "--preload",
    action="store_true",
    default="",
    help="whether to preload embs if possible",
)
parser.add_argument(
    "--dataset-layout",
    type=str,
    default="split",
    choices=["split", "flat"],
    help="'split' for root/train and root/test; 'flat' for class folders directly under root",
)
parser.add_argument("--fname", type=str, default="", help="model architecture")
parser.add_argument(
    "--model-name", type=str, default="deit_base", help="model architecture"
)
parser.add_argument(
    "--pretrained", type=str, help="path to pretrained model", default=""
)
parser.add_argument(
    "--use-pretrained-eff", action="store_true", help="Use pretrained EfficientNetV2-S weights"
)
parser.add_argument(
    "--device", type=str, default="cuda:0", help="device to run script on"
)
parser.add_argument(
    "--normalize",
    type=bool,
    default=True,
    help="whether to standardize images before feeding to nework",
)
parser.add_argument(
    "--root-path", type=str, default="", help="root directory to data"
)
parser.add_argument(
    "--image-folder",
    type=str,
    default="imagenet_full_size/061417/",
    help="image directory inside root_path",
)
parser.add_argument(
    "--subset-path", type=str, default=None, help="name of dataset to evaluate on"
)
parser.add_argument(
    "--output-dir", type=str, help="directory for the results and outputs"
)
parser.add_argument("--seeds", type=int, nargs="+", help="Seeds for running")

parser.add_argument(
    "--freeze-epochs",
    type=int,
    default=10,
    help="Number of initial epochs where ViT and EfficientNet are frozen",
)

parser.add_argument(
    "--encoder-lr",
    type=float,
    default=1e-5,
    help="Learning rate for ViT and EfficientNet after unfreezing",
)

parser.add_argument(
    "--head-lr",
    type=float,
    default=3e-4,
    help="Learning rate for projectors, scalers, and classifier",
)
parser.add_argument(
    "--epochs",
    type=int,
    default=100,
    help="Total number of epochs including freeze-epochs",
)
parser.add_argument(
    "--batch-size",
    type=int,
    default=128,
)
# [vá TN-A1] bốn tham số thêm: color-jitter (dòng gốc bị chú thích), tích luỹ gradient, dừng sớm, nối tiếp
parser.add_argument("--color-jitter", type=float, default=0.5,
                    help="[vá TN-A1] brightness của ColorJitter; 0 = tắt (mã công bố tắt, Bảng II bật)")
parser.add_argument("--accum", type=int, default=1,
                    help="[vá TN-A1] số batch tích luỹ trước mỗi optimizer.step; batch hiệu dụng = batch-size x accum")
parser.add_argument("--patience", type=int, default=0,
                    help="[vá TN-A1] dừng sớm sau N epoch val_acc không tăng; 0 = tắt")
parser.add_argument("--resume", action="store_true",
                    help="[vá TN-A1] nếu output_dir/last.pt có thì nạp và chạy tiếp từ epoch kế")

args = parser.parse_args()


def load_pretrained(encoder, pretrained):
    checkpoint = torch.load(pretrained, map_location="cpu")
    try:
        pretrained_dict = {
            k.replace("module.", ""): v for k, v in checkpoint["target_encoder"].items()
        }
    except Exception:
        pretrained_dict = {
            k.replace("module.", ""): v for k, v in checkpoint["teacher"].items()
        }
    for k, v in encoder.state_dict().items():
        if k not in pretrained_dict:
            logger.info(f'key "{k}" could not be found in loaded state dict')
        elif pretrained_dict[k].shape != v.shape:
            logger.info(
                f'key "{k}" is of different shape in model and loaded state dict'
            )
            pretrained_dict[k] = v
    msg = encoder.load_state_dict(pretrained_dict, strict=False)
    print(encoder)
    logger.info(f"loaded pretrained model with msg: {msg}")
    try:
        logger.info(
            f'loaded pretrained encoder from epoch: {checkpoint["epoch"]} '
            f"path: {pretrained}"
        )
    except Exception:
        pass
    del checkpoint
    return encoder


def init_model(device, pretrained, model_name, patch_size, res):
    encoder = deit.__dict__[model_name](
        img_size=[res], patch_size=patch_size, predictor_embed_dim=384
    )
    encoder.to(device)
    encoder = load_pretrained(encoder=encoder, pretrained=pretrained)

    return encoder


class FusionVitEff(nn.Module):
    def __init__(
        self,
        vit_encoder,
        num_classes,
        effnet_name="tf_efficientnetv2_s",
        vit_dim=768,
        proj_dim=512,
        hidden_dim=512,
        dropout=0.2,
        freeze_vit=False,
        freeze_effnet=False,
        use_pretrained_eff=False,
    ):
        super().__init__()

        # ViT branch
        self.vit = vit_encoder

        if freeze_vit:
            for p in self.vit.parameters():
                p.requires_grad = False

        self.vit_projector = nn.Sequential(
            nn.Linear(vit_dim, proj_dim),
            nn.LayerNorm(proj_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )

        self.vit_scaler = nn.Sequential(
            nn.Linear(proj_dim, proj_dim),
            nn.LayerNorm(proj_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(proj_dim, proj_dim),
        )

        # EfficientNetV2-S branch
        self.effnet = timm.create_model(
            effnet_name,
            pretrained=use_pretrained_eff,
            num_classes=0,
            global_pool="avg",
        )

        eff_dim = self.effnet.num_features

        if freeze_effnet:
            for p in self.effnet.parameters():
                p.requires_grad = False

        self.eff_projector = nn.Sequential(
            nn.Linear(eff_dim, proj_dim),
            nn.LayerNorm(proj_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )

        self.eff_scaler = nn.Sequential(
            nn.Linear(proj_dim, proj_dim),
            nn.LayerNorm(proj_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(proj_dim, proj_dim),
        )

        # -------------------------
        # Fusion classifier
        # -------------------------
        fused_dim = 2 * proj_dim

        self.classifier = nn.Sequential(
            nn.Linear(fused_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, num_classes),
        )

    def forward_vit(self, x):
        z = self.vit(x)

        # JEPA ViT usually returns patch embeddings: [B, N, 768]
        if z.ndim == 3:
            z = z.mean(dim=1)

        # If already pooled: [B, 768]
        elif z.ndim == 2:
            pass

        else:
            raise ValueError(f"Unexpected ViT output shape: {z.shape}")

        return z

    def forward(self, x, return_features=False):
        # ViT branch
        f_vit = self.forward_vit(x)  # [B, 768]
        f_vit = self.vit_projector(f_vit)  # [B, proj_dim]
        f_vit = self.vit_scaler(f_vit)  # [B, proj_dim]

        # EfficientNetV2-S branch
        f_eff = self.effnet(x)  # [B, eff_dim]
        f_eff = self.eff_projector(f_eff)  # [B, proj_dim]
        f_eff = self.eff_scaler(f_eff)  # [B, proj_dim]

        # Fusion
        f_fused = torch.cat([f_eff, f_vit], dim=1)

        logits = self.classifier(f_fused)

        if return_features:
            return {
                "logits": logits,
                "f_vit": f_vit,
                "f_eff": f_eff,
                "f_fused": f_fused,
            }

        return logits


def train_one_epoch(model, loader, criterion, optimizer, device, accum=1):
    model.train()

    total_loss = 0.0
    total_correct = 0
    total_samples = 0

    # [vá TN-A1] tích luỹ gradient: step mỗi `accum` batch (và ở batch cuối), loss chia accum để trung bình đúng
    n_batch = len(loader)
    optimizer.zero_grad(set_to_none=True)
    for i_batch, (images, labels) in enumerate(loader, 1):
        images = images.to(device, non_blocking=True)
        labels = labels.to(device, non_blocking=True)

        logits = model(images)
        loss = criterion(logits, labels)
        (loss / accum).backward()
        if i_batch % accum == 0 or i_batch == n_batch:
            optimizer.step()
            optimizer.zero_grad(set_to_none=True)

        batch_size = labels.size(0)

        total_loss += loss.item() * batch_size
        total_correct += (logits.argmax(dim=1) == labels).sum().item()
        total_samples += batch_size

    avg_loss = total_loss / total_samples
    avg_acc = total_correct / total_samples

    return avg_loss, avg_acc


@torch.no_grad()
def evaluate_loss_acc(model, loader, criterion, device):
    model.eval()

    total_loss = 0.0
    total_correct = 0
    total_samples = 0

    for images, labels in loader:
        images = images.to(device, non_blocking=True)
        labels = labels.to(device, non_blocking=True)

        logits = model(images)
        loss = criterion(logits, labels)

        batch_size = labels.size(0)

        total_loss += loss.item() * batch_size
        total_correct += (logits.argmax(dim=1) == labels).sum().item()
        total_samples += batch_size

    avg_loss = total_loss / total_samples
    avg_acc = total_correct / total_samples

    return avg_loss, avg_acc


def compute_class_weights(dataset, indices, num_classes):
    labels = np.array(dataset.targets)
    selected_labels = labels[indices]

    counts = np.bincount(selected_labels, minlength=num_classes)
    counts = np.maximum(counts, 1)

    weights = len(selected_labels) / (num_classes * counts)
    weights = torch.tensor(weights, dtype=torch.float32)

    return weights


def set_encoder_trainable(model, trainable: bool):
    for p in model.vit.parameters():
        p.requires_grad = trainable

    for p in model.effnet.parameters():
        p.requires_grad = trainable


def make_staged_optimizer(model, encoder_lr, head_lr, weight_decay):
    """
    Creates an optimizer with different learning rates:

    - ViT encoder: encoder_lr
    - EfficientNet encoder: encoder_lr
    - projectors/scalers/classifier: head_lr
    """

    encoder_params = list(model.vit.parameters()) + list(model.effnet.parameters())

    head_params = (
        list(model.vit_projector.parameters())
        + list(model.vit_scaler.parameters())
        + list(model.eff_projector.parameters())
        + list(model.eff_scaler.parameters())
        + list(model.classifier.parameters())
    )

    optimizer = torch.optim.AdamW(
        [
            {
                "params": encoder_params,
                "lr": encoder_lr,
                "name": "encoders",
            },
            {
                "params": head_params,
                "lr": head_lr,
                "name": "heads",
            },
        ],
        weight_decay=weight_decay,
    )

    return optimizer

def build_datasets_and_splits(
    data_root,
    train_transform,
    eval_transform,
    val_ratio=0.1,
    test_ratio=0.1,
    seed=None,
    dataset_layout="split",
):
    data_root = Path(data_root)

    if dataset_layout == "split":
        train_dir = data_root / "train"
        test_dir = data_root / "test"

        full_train_aug = datasets.ImageFolder(root=str(train_dir), transform=train_transform)
        full_train_eval = datasets.ImageFolder(root=str(train_dir), transform=eval_transform)
        test_dataset = datasets.ImageFolder(root=str(test_dir), transform=eval_transform)

        targets = np.array(full_train_aug.targets)
        indices = np.arange(len(targets))

        train_indices, val_indices = train_test_split(
            indices,
            test_size=val_ratio,
            random_state=seed,
            shuffle=True,
            stratify=targets,
        )

        train_dataset = Subset(full_train_aug, train_indices)
        val_dataset = Subset(full_train_eval, val_indices)

        class_weight_base_dataset = full_train_aug
        class_weight_indices = train_indices

    elif dataset_layout == "flat":
        full_aug = datasets.ImageFolder(root=str(data_root), transform=train_transform)
        full_eval = datasets.ImageFolder(root=str(data_root), transform=eval_transform)

        targets = np.array(full_aug.targets)
        indices = np.arange(len(targets))

        trainval_indices, test_indices = train_test_split(
            indices,
            test_size=test_ratio,
            random_state=seed,
            shuffle=True,
            stratify=targets,
        )

        trainval_targets = targets[trainval_indices]

        train_indices, val_indices = train_test_split(
            trainval_indices,
            test_size=val_ratio,
            random_state=seed,
            shuffle=True,
            stratify=trainval_targets,
        )

        train_dataset = Subset(full_aug, train_indices)
        val_dataset = Subset(full_eval, val_indices)
        test_dataset = Subset(full_eval, test_indices)

        class_weight_base_dataset = full_aug
        class_weight_indices = train_indices

    else:
        raise ValueError(f"Unknown dataset_layout: {dataset_layout}")

    return (
        train_dataset,
        val_dataset,
        test_dataset,
        class_weight_base_dataset,
        class_weight_indices,
        class_weight_base_dataset.classes,
    )


# Main training function
def train_fusion_vit_eff(
    model,
    data_root=None,
    output_dir="./runs/fusion_vit_eff",
    img_size=224,
    val_ratio=0.1,
    epochs=100,
    batch_size=64,
    freeze_epochs=10,
    encoder_lr=1e-5,
    head_lr=3e-4,
    weight_decay=1e-4,
    num_workers=0,
    seed=None,
    use_amp=True,
    wandb_run=None,
    dataset_layout="split",
    test_ratio=0.1,
    color_jitter=0.0,  # [vá TN-A1]
    accum=1,           # [vá TN-A1]
    patience=0,        # [vá TN-A1]
    resume=False,      # [vá TN-A1]
):
    set_seed(seed)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    data_root = Path(data_root)
    train_dir = data_root / "train"
    test_dir = data_root / "test"

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    best_ckpt_path = output_dir / "best_model.pt"
    final_metrics_dir = output_dir / "test_metrics"
    final_metrics_dir.mkdir(parents=True, exist_ok=True)

    # -------------------------
    # Transforms
    # -------------------------
    train_transform = transforms.Compose(
        [
            transforms.Resize((img_size, img_size)),
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.RandomVerticalFlip(p=0.5),
            # [vá TN-A1] dòng gốc `# transforms.ColorJitter(brightness=0.5)` bị chú thích; ablation nocolorjitter của
            # tác giả cho F1 89,62 còn Bảng II là 93,21 → bật lại, điều khiển bằng --color-jitter
            *([transforms.ColorJitter(brightness=color_jitter)] if color_jitter > 0 else []),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225],
            ),
        ]
    )

    eval_transform = transforms.Compose(
        [
            transforms.Resize((img_size, img_size)),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225],
            ),
        ]
    )

    (
        train_dataset,
        val_dataset,
        test_dataset,
        class_weight_base_dataset,
        class_weight_indices,
        class_names,
    ) = build_datasets_and_splits(
        data_root=data_root,
        train_transform=train_transform,
        eval_transform=eval_transform,
        val_ratio=val_ratio,
        test_ratio=test_ratio,
        seed=seed,
        dataset_layout=dataset_layout,
    )

    num_classes = len(class_names)

    print("class names:", class_names)
    print(f"\nTrain samples: {len(train_dataset)}")
    print(f"Val samples:   {len(val_dataset)}")
    print(f"Test samples:  {len(test_dataset)}")

    # -------------------------
    # DataLoaders
    # -------------------------
    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=True,
        drop_last=False,
    )

    val_loader = DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True,
        drop_last=False,
    )

    test_loader = DataLoader(
        test_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True,
        drop_last=False,
    )

    class_weights = compute_class_weights(
        dataset=class_weight_base_dataset,
        indices=class_weight_indices,
        num_classes=num_classes,
    ).to(device)
    criterion = nn.CrossEntropyLoss(weight=class_weights)

    model = model.to(device)

    # Stage 1 starts with frozen encoders
    set_encoder_trainable(model, trainable=False)

    optimizer = make_staged_optimizer(
        model=model,
        encoder_lr=encoder_lr,
        head_lr=head_lr,
        weight_decay=weight_decay,
    )

    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer,
        T_max=epochs,
    )

    # -- train loop
    best_val_acc = -1.0
    history = []
    # [vá TN-A1] nối tiếp: last.pt ghi mỗi epoch (model + optimizer + scheduler + history + đếm dừng sớm)
    last_ckpt_path = output_dir / "last.pt"
    start_epoch = 1
    ko_cai_thien = 0
    if resume and last_ckpt_path.exists():
        ck = torch.load(last_ckpt_path, map_location=device, weights_only=False)
        model.load_state_dict(ck["model_state_dict"])
        optimizer.load_state_dict(ck["optimizer_state_dict"])
        scheduler.load_state_dict(ck["scheduler_state_dict"])
        best_val_acc = ck["best_val_acc"]
        history = ck["history"]
        ko_cai_thien = ck.get("ko_cai_thien", 0)
        start_epoch = epochs + 1 if ck.get("xong") else ck["epoch"] + 1
        if start_epoch > freeze_epochs:
            set_encoder_trainable(model, trainable=True)
        print(f"[resume] nạp {last_ckpt_path}: đã xong epoch {ck['epoch']}, best_val_acc={best_val_acc:.4f}, "
              f"ko_cai_thien={ko_cai_thien}, chạy tiếp từ epoch {start_epoch}", flush=True)
    for epoch in range(start_epoch, epochs + 1):
        if epoch == 1:
            print("\nStage 1: frozen ViT + EfficientNet encoders", flush=True)
            set_encoder_trainable(model, trainable=False)

        if epoch == freeze_epochs + 1:
            print("\nStage 2: unfreezing ViT + EfficientNet encoders", flush=True)
            set_encoder_trainable(model, trainable=True)

        if epoch <= freeze_epochs:
            stage = "frozen_encoders"
        else:
            stage = "full_finetuning"

        print(f"\nEpoch [{epoch}/{epochs}] | stage={stage}", flush=True)

        train_loss, train_acc = train_one_epoch(
            model=model,
            loader=train_loader,
            criterion=criterion,
            optimizer=optimizer,
            device=device,
            accum=accum,  # [vá TN-A1]
        )

        val_loss, val_acc = evaluate_loss_acc(
            model=model,
            loader=val_loader,
            criterion=criterion,
            device=device,
        )

        scheduler.step()

        encoder_current_lr = optimizer.param_groups[0]["lr"]
        head_current_lr = optimizer.param_groups[1]["lr"]

        epoch_log = {
            "epoch": epoch,
            "stage": stage,
            "encoder_lr": encoder_current_lr,
            "head_lr": head_current_lr,
            "train_loss": train_loss,
            "train_acc": train_acc,
            "val_loss": val_loss,
            "val_acc": val_acc,
        }
        if wandb_run is not None:
            wandb_run.log(epoch_log, step=epoch)

        history.append(epoch_log)

        print(
            f"stage={stage} | "
            f"train_loss={train_loss:.4f} | "
            f"train_acc={train_acc:.4f} | "
            f"val_loss={val_loss:.4f} | "
            f"val_acc={val_acc:.4f} | "
            f"encoder_lr={encoder_current_lr:.6e} | "
            f"head_lr={head_current_lr:.6e}",
            flush=True,
        )

        if val_acc > best_val_acc:
            best_val_acc = val_acc

            torch.save(
                {
                    "epoch": epoch,
                    "model_state_dict": model.state_dict(),
                    "optimizer_state_dict": optimizer.state_dict(),
                    "scheduler_state_dict": scheduler.state_dict(),
                    "best_val_acc": best_val_acc,
                    "class_names": class_names,
                    "config": {
                        "data_root": str(data_root),
                        "img_size": img_size,
                        "val_ratio": val_ratio,
                        "epochs": epochs,
                        "batch_size": batch_size,
                        "freeze_epochs": freeze_epochs,
                        "encoder_lr": encoder_lr,
                        "head_lr": head_lr,
                        "weight_decay": weight_decay,
                        "seed": seed,
                        "dataset_layout": dataset_layout,
                        "test_ratio": test_ratio,
                    },
                },
                best_ckpt_path,
            )

            print(f"Saved new best model: val_acc={best_val_acc:.4f}", flush=True)
            ko_cai_thien = 0  # [vá TN-A1]
        else:
            ko_cai_thien += 1  # [vá TN-A1]

        with open(output_dir / "history.json", "w") as f:
            json.dump(history, f, indent=2)

        save_training_plots(history, output_dir)

        # [vá TN-A1] dừng sớm + ghi last.pt (ghi tạm rồi đổi tên: đứt phiên giữa lúc ghi không làm hỏng file)
        dung_som = bool(patience) and ko_cai_thien >= patience
        tmp_path = last_ckpt_path.with_suffix(".tmp")
        torch.save(
            {
                "epoch": epoch,
                "model_state_dict": model.state_dict(),
                "optimizer_state_dict": optimizer.state_dict(),
                "scheduler_state_dict": scheduler.state_dict(),
                "best_val_acc": best_val_acc,
                "history": history,
                "ko_cai_thien": ko_cai_thien,
                "xong": dung_som or epoch == epochs,
            },
            tmp_path,
        )
        tmp_path.replace(last_ckpt_path)
        if dung_som:
            print(f"[dừng sớm] val_acc không tăng {patience} epoch liền, dừng ở epoch {epoch}/{epochs}; "
                  f"best_val_acc={best_val_acc:.4f}", flush=True)
            break

    print("\nLoading best checkpoint...")
    ckpt = torch.load(best_ckpt_path, map_location=device)
    model.load_state_dict(ckpt["model_state_dict"])

    print(f"Best epoch: {ckpt['epoch']}")
    print(f"Best val accuracy: {ckpt['best_val_acc']:.4f}")

    evaluator = ClassificationEvaluator(device=device)

    test_metrics, test_cm = evaluator.evaluate(
        model=model,
        loader=test_loader,
        averages=["macro", "micro"],
        results_path=str(final_metrics_dir),
        save_confusion=True,
    )

    print("\n========== Test metrics ==========")
    for k, v in test_metrics.items():
        print(f"{k}: {v}")

    if wandb_run is not None:
        wandb_run.log({f"test/{k}": v for k, v in test_metrics.items()})
    print("\nConfusion matrix:")
    print(test_cm)

    return {
        "model": model,
        "best_ckpt_path": str(best_ckpt_path),
        "history": history,
        "test_metrics": test_metrics,
        "test_confusion_matrix": test_cm,
        "class_names": class_names,
    }


project = "Solar-Panel-Defect-Classification"
for seed in args.seeds:
    run_name = f"{Path(args.output_dir).name}_seed_{seed}"
    with wandb.init(
        project=project,
        name=run_name,
        config={
            "seed": seed,
            "epochs": args.epochs,
            "freeze_epochs": args.freeze_epochs,
            "encoder_lr": args.encoder_lr,
            "head_lr": args.head_lr,
            "batch_size": args.batch_size,
            "pretrained": args.pretrained,
            "model_name": args.model_name,
            "patch_size": args.patch_size,
            "res": args.res,
            "output_dir": args.output_dir,
        },
    ) as run:

        encoder = init_model(
            args.device, args.pretrained, args.model_name, args.patch_size, args.res
        )
        data_root = Path(args.root_path) / args.image_folder

        if args.dataset_layout == "split":
            tmp_dataset = datasets.ImageFolder(root=str(data_root / "train"))
        else:
            tmp_dataset = datasets.ImageFolder(root=str(data_root))

        num_classes = len(tmp_dataset.classes)

        print("Classes used to build model:", tmp_dataset.classes)
        print("num_classes used in classifier:", num_classes)

        model = FusionVitEff(
            vit_encoder=encoder,
            num_classes=num_classes,
            use_pretrained_eff=args.use_pretrained_eff,
        )

        results = train_fusion_vit_eff(
            model=model,
            data_root=str(Path(args.root_path) / args.image_folder),
            output_dir=args.output_dir + f"_{seed}",
            img_size=224,
            val_ratio=0.1,
            test_ratio=0.1,
            dataset_layout=args.dataset_layout,
            epochs=args.epochs,
            freeze_epochs=args.freeze_epochs,
            encoder_lr=args.encoder_lr,
            head_lr=args.head_lr,
            batch_size=args.batch_size,
            weight_decay=1e-4,
            num_workers=0,
            seed=seed,
            use_amp=True,
            wandb_run=run,
            color_jitter=args.color_jitter,  # [vá TN-A1]
            accum=args.accum,                # [vá TN-A1]
            patience=args.patience,          # [vá TN-A1]
            resume=args.resume,              # [vá TN-A1]
        )
